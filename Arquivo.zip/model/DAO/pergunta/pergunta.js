/*************************************************************************************
 * Objetivo: Arquivo responsável pela conexão com o banco da tabela pergunta
 * Data: 20/09/2026
 * Autor: Julio Augusto
 * Versão: 1.0
 * *********************************************************************************/


const knex = require('knex')
const knexConfig = require('../../database_config_knex/knexFile.js')
const knexConex = knex(knexConfig.development)

// insert de pergunta
const insertPergunta = async (pergunta, idTarefa) => {
    let sql = `INSERT INTO tbl_pergunta (tipo, texto, imagem, obrigatoria, ordem, id_tarefa)
               VALUES (?, ?, ?, ?, ?, ?)`

    try {
        let response = await knexConex.raw(sql, [
            pergunta.tipo,
            pergunta.texto,
            pergunta.imagem,
            pergunta.obrigatoria,
            pergunta.ordem,
            idTarefa
        ])

        if(response) return response[0].insertId 

    } catch (error) { console.log(error) }

    return false
}

// update de pergunta
const updatePergunta = async (pergunta) => {
    let sql = `UPDATE tbl_pergunta
               SET tipo = ?,
                   texto = ?,
                   imagem = ?,
                   obrigatoria = ?,
                   ordem = ?
               WHERE id = ?`
    try {
        let response = await knexConex.raw(sql, [
            pergunta.tipo,
            pergunta.texto,
            pergunta.imagem,
            pergunta.obrigatoria,
            pergunta.ordem,
            pergunta.id
        ])

        if(response) return response

    } catch (error) { console.log(error) }

    return false
}

// select de todas perguntas
const selectAllPergunta = async () => {
    let sql = `SELECT
                   id,
                   tipo,
                   texto,
                   imagem,
                   obrigatoria,
                   ordem,
                   id_tarefa
               FROM tbl_pergunta
               ORDER BY id DESC`
    try {
        let response = await knexConex.raw(sql)


        if(response) return response[0]
 
    } catch (error) { console.log(error) }

    return false
}

// select de uma pergunta pelo id
const selectByIdPergunta = async (id) => {
    let sql = `SELECT
                   id,
                   tipo,
                   texto,
                   imagem,
                   obrigatoria,
                   ordem,
                   id_tarefa
               FROM tbl_pergunta
               WHERE id = ?`
    try {
        let response = await knexConex.raw(sql, [id])


        if(response) return response[0]
        
    } catch (error) { console.log(error) }

    return false
}

// delete de pergunta
const deletePergunta = async (id) => {
    let sql = `DELETE FROM tbl_pergunta
               WHERE id = ?`
    try {
        let response = await knexConex.raw(sql, [id])


        if(response) return response
 
    } catch (error) { console.log(error) }

    return false
}

// listar perguntas por id_tarefa
const selectPerguntasByIdTarefa = async (idTarefa) => {
    let sql = `SELECT
                   id,
                   tipo,
                   texto,
                   imagem,
                   obrigatoria,
                   ordem,
                   id_tarefa
               FROM tbl_pergunta
               WHERE id_tarefa = ?
               ORDER BY ordem ASC`
    try {
        let response = await knexConex.raw(sql, [idTarefa])

        if(response) return response[0]
        
    } catch (error) { console.log(error) }

    return false
}



module.exports = {
    insertPergunta,
    updatePergunta,
    selectAllPergunta,
    selectByIdPergunta,
    deletePergunta,
    selectPerguntasByIdTarefa
}