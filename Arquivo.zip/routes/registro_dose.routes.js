/*************************************************************************************
 * Objetivo: Arquivo responsável pelo gerenciamento de rotas de registroDose
 * Data: 20/09/2026
 * Autor: Julio Augusto
 * Versão: 1.0
 * *********************************************************************************/


const express = require('express')
const router = express.Router()
const bodyParser = require('body-parser')
const bodyParserJSON = bodyParser.json()

const {
    inserirNovaRegistroDose,
    atualizarRegistroDose,
    listarRegistroDose,
    buscarRegistroDose,
    excluirRegistroDose,
    marcarDoseComoTomada
} = require('../controller/registro_dose/controller_registro_dose.js')

// ---------------- registroDose -----------------

// endpoint para inserir registroDose
router.post('/',bodyParserJSON, async (req,res) => {
    // recebe o conteudo dentro do body da requisição
    let dados = req.body
    let contentType = req.headers['content-type']

    let result = await inserirNovaRegistroDose(dados,contentType)
    res.status(result.status_code).json(result)
})

// endpoint para retornar todas registroDoses
router.get('/', async (req,res) => {
    let result = await listarRegistroDose()
    res.status(result.status_code).json(result)
})

// endpoint para buscar um registroDose pelo id
router.get('/:id', async (req,res) => {
    let id = req.params.id
    let result = await buscarRegistroDose(id)
    res.status(result.status_code).json(result)
})

// endpoint para marcar uma dose como tomada
router.put('/:id/marcar-como-tomada', bodyParserJSON, async (req,res) => {
    let id          = req.params.id                 // Recebe o id por parametro
    let result      = await marcarDoseComoTomada(id)
    res.status(result.status_code).json(result)
})

// endpoint para atualizar um registroDose pelo id
router.put('/:id', bodyParserJSON, async (req,res) => {
    let id          = req.params.id                 // Recebe o id por parametro
    let dados       = req.body                      // Recebe os dados do body da requisição
    let contentType = req.headers['content-type']   // Recebe o ContentType do header da requisição
    
    let result      = await atualizarRegistroDose(dados, id, contentType)
    res.status(result.status_code).json(result)
})

// endpoint para deletar um registroDose pelo id
router.delete('/:id', async (req,res) => {
    let id = req.params.id
    let result = await excluirRegistroDose(id)
    res.status(result.status_code).json(result)
})

module.exports = router
