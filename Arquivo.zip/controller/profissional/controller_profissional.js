/*************************************************************************************
 * Objetivo: Arquivo responsável pelo CRUD da tabela profissional
 * Data: 20/09/2026
 * Autor: Julio Augusto
 * Versão: 1.1
 * *********************************************************************************/

const config_message = require('../module/configMessages.js')
const profissionalDAO = require('../../model/DAO/profissional/profissional.js')
const usuarioController = require('../usuario/controller_usuario.js')
const vinculoController = require('../vinculo/controller_vinculo.js')
const profissionalEspecialidadeController = require('../profissional_especialidade/controller_profissional_especialidade.js')
const administradorProfissionalDAO = require('../../model/DAO/administrador_profissional/administrador_profissional.js')
const bcrypt = require('../../services/bcrypt.js')
const { decodeJWT } = require('../../middleware/middlewareJWT.js')
const {uploadFiles} = require('../upload/controller_upload_azure.js')

// inserir nova profissional
const inserirNovaProfissional = async (profissional, foto_avatar, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))
    try {
        let validar = await validarDados(profissional, contentType)
        if(validar) return validar // 400 ou 415

        // confere e-mail/CPF/CRP ANTES de criar qualquer coisa (evita usuário "órfão" no banco)
        const duplicado = await profissionalDAO.selectCampoDuplicado(profissional)
        if(duplicado){
            const nomes = { email: 'E-mail', cpf: 'CPF', crp: 'CRP', celular: 'Celular' }
            message.ERROR_CONFLICT.message = `${nomes[duplicado]} já cadastrado.`
            message.ERROR_CONFLICT.field = `[${duplicado.toUpperCase()}] JÁ CADASTRADO`
            return message.ERROR_CONFLICT // 409
        }

        profissional.senha_hash = await bcrypt.criarHash(profissional.senha)
        profissional.nivel = 1 // define o nivel do usuario como profissional

        let resultUsuario = await usuarioController.inserirNovaUsuario(profissional, contentType)
        if(!resultUsuario.status) return resultUsuario

        // Realiza o upload da imagem do profissional
        if (foto_avatar) {
            let urlImagem = await uploadFiles(foto_avatar)

            if (!urlImagem) {
                return message.ERROR_INTERNAL_SERVER_CONTROLLER
            }

            profissional.foto_avatar = urlImagem
        }

        profissional.id_usuario = resultUsuario.response.usuario.id
        let result = await profissionalDAO.insertProfissional(profissional)

        if(!result){
            // desfaz o usuário criado, senão o e-mail fica "preso" sem profissional
            await usuarioController.excluirUsuario(profissional.id_usuario)
            return message.ERROR_INTERNAL_SERVER_MODEL
        }

        // registra o pedido de aprovação (pendente) para o admin avaliar
        await administradorProfissionalDAO.insertSolicitacaoPendente(result)

        let resultBuscarUsuario = await usuarioController.buscarUsuario(profissional.id_usuario)
        if(resultBuscarUsuario.status){
            delete resultBuscarUsuario.response.usuario[0].senha
            delete resultBuscarUsuario.response.usuario[0].senha_hash
            delete resultBuscarUsuario.response.usuario[0].id
            Object.assign(profissional, resultBuscarUsuario.response.usuario[0])
        }

        delete profissional.senha
        delete profissional.senha_hash

        profissional.id = result

        for (const especialidade of profissional.id_especialidade || []) {
            let profissionalEspecialidade = { id_especialidade: especialidade, id_profissional: profissional.id }
            let resultInsertEspecialidade = await profissionalEspecialidadeController.inserirNovaProfissionalEspecialidade(profissionalEspecialidade, 'application/json')
            
            if(!resultInsertEspecialidade.status) return message.SUCESS_CREATED_ITEM_WARNING
        }

        let resultBuscarEspecialidades = await profissionalEspecialidadeController.buscarEspecialidadesIdProfissional(profissional.id)
        if(resultBuscarEspecialidades.status){
            profissional.especialidade = resultBuscarEspecialidades.response.profissionalEspecialidade
            delete profissional.id_especialidade
        }

        return await montarMensagem(message, message.SUCESS_CREATED_ITEM, profissional)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER
}

// atualizar profissional
const atualizarProfissional = async (profissional, id, foto_avatar, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        let validar = await validarDados(profissional, contentType)
        if(validar) return validar // 400 ou 415

        let resultBuscarId = await buscarProfissional(id)
        if(!resultBuscarId.status) return resultBuscarId // 400 e 404

        // Realiza o upload da imagem do profissional
        if (foto_avatar) {
            let urlImagem = await uploadFiles(foto_avatar)

            if (!urlImagem) {
                return message.ERROR_INTERNAL_SERVER_CONTROLLER
            }

            profissional.foto_avatar = urlImagem
        }

        profissional.id = Number(id)
        let result = await profissionalDAO.updateProfissional(profissional)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        delete profissional.senha
        delete profissional.senha_hash

        let resultDeleteEspecialidades = await profissionalEspecialidadeController.excluirProfissionalEspecialidadeByIdProfissional(id)

        if(resultDeleteEspecialidades.status){
            for (const especialidade of profissional.id_especialidade || []) {
                let profissionalEspecialidade = { id_especialidade: especialidade, id_profissional: profissional.id }
                let resultInsertEspecialidade = await profissionalEspecialidadeController.inserirNovaProfissionalEspecialidade(profissionalEspecialidade, 'application/json')
                
                if(!resultInsertEspecialidade.status) return message.SUCESS_CREATED_ITEM_WARNING
            }

            let resultBuscarEspecialidades = await profissionalEspecialidadeController.buscarEspecialidadesIdProfissional(profissional.id)
            if(resultBuscarEspecialidades.status){
                profissional.especialidade = resultBuscarEspecialidades.response.profissionalEspecialidade
                delete profissional.id_especialidade
            }
            
        }

        return await montarMensagem(message, message.SUCESS_UPDATE_ITEM, profissional)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// listar todas profissionals
const listarProfissional = async () => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        let result = await profissionalDAO.selectAllProfissional()

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        // verfica se o array é vazio
        if(result.length <= 0) return message.ERROR_NOT_FOUND // status_code 404

        for (let profissional of result) {
            await completarDadosProfissional(profissional)
        }

        let listarProfissionalMessage = await montarMensagem(message, message.SUCESS_RESPONSE, result)
        message.DEFAULT_MESSAGE.response.count = result.length

        return listarProfissionalMessage // status_code 200

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// busca profissionais aprovados por nome ou e-mail (para o paciente escolher o seu profissional)
const buscarProfissionaisPorTermo = async (termo) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        termo = String(termo ?? '').trim()

        // poucas letras: devolve lista vazia em vez de erro
        if(termo.length < 2 || termo.length > 100)
            return await montarMensagem(message, message.SUCESS_RESPONSE, [])

        let result = await profissionalDAO.selectBuscaProfissionaisAprovados(termo)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        return await montarMensagem(message, message.SUCESS_RESPONSE, result)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// buscar profissional pelo id (tabela profissional)
const buscarProfissional = async (id) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

       const validarID = await validarId(id)
       if(validarID) return validarID

        let result = await profissionalDAO.selectByIdProfissional(id)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        if(result.length < 1) return message.ERROR_NOT_FOUND // 404

        for (let profissional of result) {
            await completarDadosProfissional(profissional)
        }

        return await montarMensagem(message, message.SUCESS_RESPONSE, result)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// buscar profissional pelo id do usuario (id_usuario)
const buscarProfissionalByIdUsuario = async (idUsuario) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        const validarID = await validarId(idUsuario)
        if(validarID) return validarID

        let result = await profissionalDAO.selectByIdUsuarioProfissional(idUsuario)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        if(result.length < 1) return message.ERROR_NOT_FOUND // 404

        for (let profissional of result) {
            await completarDadosProfissional(profissional)
        }

        return await montarMensagem(message, message.SUCESS_RESPONSE, result)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// excluir profissional pelo id
const excluirProfissional = async (id) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let resultBuscarId = await buscarProfissional(id)
        if(!resultBuscarId.status) return resultBuscarId // 400 e 404

        let result = await profissionalDAO.deleteProfissional(id)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        return await montarMensagem(message, message.SUCESS_DELETE_ITEM)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

const buscarProfissionalByToken = async (token) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let decodedToken = await decodeJWT(token)
        if(!decodedToken.status) return message.ERROR_INVALID_TOKEN // 401

        // o id do token é o id do USUARIO, não do profissional
        return await buscarProfissionalByIdUsuario(decodedToken.decode.id) // 200 ou 400 ou 404

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

const primeiroAcessoProfissional = async (token) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        let resultToken = await obterIdProfissionalByToken(token)
        if(resultToken.erro) return resultToken.erro

        let idProfissional = resultToken.id
        let result = await profissionalDAO.updatePrimeiroAcessoProfissional(idProfissional)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        return await montarMensagem(message, message.SUCESS_UPDATE_ITEM, {
            id: idProfissional,
            primeiro_acesso_concluido: 1
        })
    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

const editarProfissionalByToken = async (profissional, token, foto_avatar, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let resultToken = await obterIdProfissionalByToken(token)
        if(resultToken.erro) return resultToken.erro // 401, 400 ou 404

        let idProfissional = resultToken.id

        let validar = await validarDadosAtualizacao(profissional, contentType)
        if(validar) return validar // 400 ou 415

        // Realiza o upload da imagem do profissional
        if (foto_avatar) {
            let urlImagem = await uploadFiles(foto_avatar)

            if (!urlImagem) {
                return message.ERROR_INTERNAL_SERVER_CONTROLLER
            }

            profissional.foto_avatar = urlImagem
        }

        profissional.id = Number(idProfissional)
        let result = await profissionalDAO.updateProfissional(profissional)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        delete profissional.senha
        delete profissional.senha_hash

        let resultDeleteEspecialidades = await profissionalEspecialidadeController.excluirProfissionalEspecialidadeByIdProfissional(profissional.id)

        if(resultDeleteEspecialidades.status){
            for (const especialidade of profissional.id_especialidade || []) {
                let profissionalEspecialidade = { id_especialidade: especialidade, id_profissional: profissional.id }
                let resultInsertEspecialidade = await profissionalEspecialidadeController.inserirNovaProfissionalEspecialidade(profissionalEspecialidade, 'application/json')
                
                if(!resultInsertEspecialidade.status) return message.SUCESS_CREATED_ITEM_WARNING
            }

            let resultBuscarEspecialidades = await profissionalEspecialidadeController.buscarEspecialidadesIdProfissional(profissional.id)
            if(resultBuscarEspecialidades.status){
                profissional.especialidade = resultBuscarEspecialidades.response.profissionalEspecialidade
                delete profissional.id_especialidade
            }
            
        }

        return await montarMensagem(message, message.SUCESS_UPDATE_ITEM, profissional)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// listar pacientes vinculados ao profissional
const listarPacientesVinculados = async (token, filtro) => {
    const pacienteController = require('../paciente/controller_paciente.js')
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let resultToken = await obterIdProfissionalByToken(token)
        if(resultToken.erro) return resultToken.erro // 401, 400 ou 404

        let idProfissional = resultToken.id

        let result = await vinculoController.listarPacientesByIdProfissional(idProfissional, filtro);

        if (!result) return message.ERROR_INTERNAL_SERVER_MODEL

        if (!result.status) return result

        let pacientes = result.response.vinculo

        if (!Array.isArray(pacientes) || pacientes.length <= 0) {
            return message.ERROR_NOT_FOUND
        }

        for (let paciente of pacientes) {
            let resultBuscarPaciente = await pacienteController.buscarPaciente(paciente.id)

            if (resultBuscarPaciente.status && resultBuscarPaciente.response?.usuario?.length > 0) {
                paciente = resultBuscarPaciente.response.paciente
            }
        }

        let listarPacientesMessage = await montarMensagem(
            message,
            message.SUCESS_RESPONSE,
            pacientes
        );

        message.DEFAULT_MESSAGE.response.count = pacientes.length

        listarPacientesMessage.response.paciente = listarPacientesMessage.response.profissional
        delete listarPacientesMessage.response.profissional

        return listarPacientesMessage

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// insere um novo vinculo entre profissional e paciente
const inserirNovoVinculo = async (token, idPaciente) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let resultToken = await obterIdProfissionalByToken(token)
        if(resultToken.erro) return resultToken.erro // 401, 400 ou 404

        let idProfissional = resultToken.id

        let resultBuscarIdPaciente = await usuarioController.buscarUsuario(idPaciente)
        if(!resultBuscarIdPaciente.status) return resultBuscarIdPaciente // 400 e 404

        let vinculo = {
            id_profissional: idProfissional,
            id_paciente: idPaciente
        }

        let resultInsertVinculo = await vinculoController.inserirNovoVinculoByProfissional(vinculo)

        if(!resultInsertVinculo) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        return await montarMensagem(message, message.SUCESS_CREATED_ITEM, vinculo)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// exclui um vinculo entre profissional e paciente
const excluirVinculo = async (token, idPaciente) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let resultToken = await obterIdProfissionalByToken(token)
        if(resultToken.erro) return resultToken.erro // 401, 400 ou 404

        let idProfissional = resultToken.id

        let result = await vinculoController.excluirVinculoPacienteProfissional(idPaciente, idProfissional)

        if(!result.status) return result // 400, 404 e 500
        
        return await montarMensagem(message, message.SUCESS_DELETE_ITEM)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// decodifica o token e converte o id_usuario nele contido no id do profissional
// retorna { id } em caso de sucesso ou { erro } com a mensagem de erro (401, 400 ou 404)
const obterIdProfissionalByToken = async (token) => {
    let message = JSON.parse(JSON.stringify(config_message))

    let decodedToken = await decodeJWT(token)
    if(!decodedToken.status) return { erro: message.ERROR_INVALID_TOKEN } // 401

    let resultProfissional = await buscarProfissionalByIdUsuario(decodedToken.decode.id)
    if(!resultProfissional.status) return { erro: resultProfissional } // 400 e 404

    return { id: resultProfissional.response.profissional[0].id }
}

// junta ao profissional os dados do usuario (sem senha) e as especialidades
const completarDadosProfissional = async (profissional) => {
    let usuario = await usuarioController.buscarUsuario(profissional.id_usuario)

    if (usuario.status) {
        delete usuario.response.usuario[0].senha
        delete usuario.response.usuario[0].senha_hash
        delete usuario.response.usuario[0].id
        Object.assign(profissional, usuario.response.usuario[0])
    }

    let especialidades = await profissionalEspecialidadeController.buscarEspecialidadesIdProfissional(profissional.id)
    if(especialidades.status) {
        profissional.especialidade = especialidades.response.profissionalEspecialidade
        delete profissional.id_especialidade
    }

    return profissional
}

const validarDados = async (profissional, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))

    // Valida se o formato de dados é JSON
    // Valida o formato da requisição
    if(String(contentType).toLowerCase() != 'application/json' && !String(contentType).toLowerCase().includes('multipart/form-data')) return message.ERROR_CONTENT_TYPE // Status code 415

    // Garante que o objeto foi informado
    if(profissional == undefined || profissional == null || typeof profissional != 'object'){
        message.ERROR_BAD_REQUEST.field = '[PROFISSIONAL] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o nome completo
    if(typeof profissional.nome_completo != 'string' || profissional.nome_completo.trim() == '' || profissional.nome_completo.length > 150){
        message.ERROR_BAD_REQUEST.field = '[NOME_COMPLETO] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o CPF
    if(profissional?.cpf == null || profissional?.cpf == undefined || typeof profissional?.cpf != 'string' || profissional?.cpf.trim() == '' || profissional?.cpf.length > 11){
        message.ERROR_BAD_REQUEST.field = '[CPF] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o CRP
    if(profissional?.crp == undefined || typeof profissional?.crp != 'string' || profissional?.crp.trim() == '' || profissional?.crp.length > 20){
        message.ERROR_BAD_REQUEST.field = '[CRP] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida a senha hash opcional
    if(profissional.senha != undefined && profissional.senha != null &&
       (typeof profissional.senha != 'string' || profissional.senha.length > 30)){
        message.ERROR_BAD_REQUEST.field = '[SENHA] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o celular opcional
    if(profissional.celular != undefined && profissional.celular != null &&
       (typeof profissional.celular != 'string' || profissional.celular.length > 20)){
        message.ERROR_BAD_REQUEST.field = '[CELULAR] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida a instituição opcional
    if(profissional.instituicao_clinica != undefined && profissional.instituicao_clinica != null &&
       (typeof profissional.instituicao_clinica != 'string' || profissional.instituicao_clinica.length > 150)){
        message.ERROR_BAD_REQUEST.field = '[INSTITUICAO_CLINICA] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o avatar opcional
    if(profissional.foto_avatar != undefined && profissional.foto_avatar != null && typeof profissional.foto_avatar != 'string'){
        message.ERROR_BAD_REQUEST.field = '[FOTO_AVATAR] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    return false
}

const validarDadosAtualizacao = async (profissional, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))

    // Valida o formato da requisição
    if(
        String(contentType).toLowerCase() != 'application/json' &&
        !String(contentType).toLowerCase().includes('multipart/form-data')
    ){
        return message.ERROR_CONTENT_TYPE
    }

    // Nome, se enviado
    if(
        profissional.nome_completo != undefined &&
        (
            typeof profissional.nome_completo != 'string' ||
            profissional.nome_completo.trim() == '' ||
            profissional.nome_completo.length > 150
        )
    ){
        message.ERROR_BAD_REQUEST.field = '[NOME_COMPLETO] INVÁLIDO'
        return message.ERROR_BAD_REQUEST
    }

    // Celular, se enviado
    if(
        profissional.celular != undefined &&
        profissional.celular != null &&
        (
            typeof profissional.celular != 'string' ||
            profissional.celular.length > 20
        )
    ){
        message.ERROR_BAD_REQUEST.field = '[CELULAR] INVÁLIDO'
        return message.ERROR_BAD_REQUEST
    }

    return false
}

const validarId = async (id) => {
    let message = JSON.parse(JSON.stringify(config_message))
    
    if(id == undefined || id == '' || id == null || id <= 0 || isNaN(id)){
        message.ERROR_BAD_REQUEST.field = '[ID] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    return false
}

const montarMensagem = async (base,status,response = null) => {
    base.DEFAULT_MESSAGE.status = status.status
    base.DEFAULT_MESSAGE.status_code = status.status_code
    base.DEFAULT_MESSAGE.message = status.message

    if(response != null) base.DEFAULT_MESSAGE.response.profissional = response

    return base.DEFAULT_MESSAGE // 200 ou 201
}

module.exports = {
    buscarProfissionaisPorTermo,
    inserirNovaProfissional,
    atualizarProfissional,
    listarProfissional,
    buscarProfissional,
    buscarProfissionalByIdUsuario,
    excluirProfissional,
    buscarProfissionalByToken,
    primeiroAcessoProfissional,
    editarProfissionalByToken,
    listarPacientesVinculados,
    inserirNovoVinculo,
    excluirVinculo
}