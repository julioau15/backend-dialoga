/*************************************************************************************
 * Objetivo: Arquivo responsável pelo CRUD da tabela consulta
 * Data: 20/09/2026
 * Autor: Julio Augusto
 * Versão: 1.0
 * *********************************************************************************/

const config_message = require('../module/configMessages.js')
const consultaDAO = require('../../model/DAO/consulta/consulta.js')
const { decodeJWT } = require('../../middleware/middlewareJWT.js')

// inserir nova consulta
const inserirNovaConsulta = async (consulta, token, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))
    try {
        let decodedToken = await decodeJWT(token)
        if(!decodedToken.status) return message.ERROR_INVALID_TOKEN

        let id = decodedToken.decode.id
        let nivel = 
        decodedToken.decode.nivel == 0 
        ? "administrador"
        : decodedToken.decode.nivel == 1
        ? "profissional"
        : decodedToken.decode.nivel == 2
        ? "paciente"
        : false

        consulta.criado_por = nivel

        let validar = await validarDados(consulta, contentType)
        if(validar) return validar // 400 ou 415

        let result = await consultaDAO.insertConsulta(consulta)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL

        consulta.id = result
        return await montarMensagem(message, message.SUCESS_CREATED_ITEM, consulta)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER
}

// atualizar consulta
const atualizarConsulta = async (consulta, token, id, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        let decodedToken = await decodeJWT(token)
        if(!decodedToken.status) return message.ERROR_INVALID_TOKEN

        let nivel = 
        decodedToken.decode.nivel == 0 
        ? "administrador"
        : decodedToken.decode.nivel == 1
        ? "profissional"
        : decodedToken.decode.nivel == 2
        ? "paciente"
        : false

        consulta.criado_por = nivel

        let validar = await validarDados(consulta, contentType)
        if(validar) return validar // 400 ou 415

        let resultBuscarId = await buscarConsulta(id)
        if(!resultBuscarId.status) return resultBuscarId // 400 e 404

        consulta.id = Number(id)
        let result = await consultaDAO.updateConsulta(consulta)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        return await montarMensagem(message, message.SUCESS_UPDATE_ITEM, consulta)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// listar todas consultas
const listarConsulta = async (filtro = {}) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        let result = await consultaDAO.selectAllConsulta(filtro)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        // verfica se o array é vazio
        if(result.length <= 0) return message.ERROR_NOT_FOUND // status_code 404

        let listarConsultaMessage = await montarMensagem(message, message.SUCESS_RESPONSE, result)
        message.DEFAULT_MESSAGE.response.count = result.length

        return listarConsultaMessage // status_code 200

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// buscar consulta pelo id
const buscarConsulta = async (id) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

       const validarID = await validarId(id)
       if(validarID) return validarID

        let result = await consultaDAO.selectByIdConsulta(id)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        if(result.length < 1) return config_message.ERROR_NOT_FOUND

        return await montarMensagem(message, message.SUCESS_RESPONSE, result)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// excluir consulta pelo id
const excluirConsulta = async (id) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let resultBuscarId = await buscarConsulta(id)
        if(!resultBuscarId.status) return resultBuscarId // 400 e 404

        let result = await consultaDAO.deleteConsulta(id)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        return await montarMensagem(message, message.SUCESS_DELETE_ITEM)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

const pacienteDAO = require('../../model/DAO/paciente/paciente.js')

// listar consultas do paciente pelo token
const listarConsultasByToken = async (token) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        let decodedToken = await decodeJWT(token)
        if(!decodedToken.status) return message.ERROR_INVALID_TOKEN

        let resultPaciente = await pacienteDAO.selectByIdUsuarioPaciente(decodedToken.decode.id)
        if(!resultPaciente) return message.ERROR_INTERNAL_SERVER_MODEL // 500
        if(resultPaciente.length < 1) return message.ERROR_NOT_FOUND // 404

        let result = await consultaDAO.selectConsultasByIdPaciente(resultPaciente[0].id)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500
        if(result.length <= 0) return message.ERROR_NOT_FOUND // 404

        let listarConsultaMessage = await montarMensagem(message, message.SUCESS_RESPONSE, result)
        message.DEFAULT_MESSAGE.response.count = result.length

        return listarConsultaMessage // 200

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// lembre de exportar: listarConsultasByToken

const validarDados = async (consulta, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))

    // Valida se o formato de dados é JSON
    // Valida o formato da requisição
    if(String(contentType).toLowerCase() != 'application/json') return message.ERROR_CONTENT_TYPE // Status code 415

    // Garante que o objeto foi informado
    if(consulta == undefined || consulta == null || typeof consulta != 'object'){
        message.ERROR_BAD_REQUEST.field = '[CONSULTA] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o nome da consulta
    if(typeof consulta.nome_da_consulta != 'string' || consulta.nome_da_consulta.trim() == '' || consulta.nome_da_consulta.length > 150){
        message.ERROR_BAD_REQUEST.field = '[NOME_DA_CONSULTA] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida a especialidade opcional
    if(consulta.especialidade != undefined && consulta.especialidade != null &&
       (typeof consulta.especialidade != 'string' || consulta.especialidade.length > 100)){
        message.ERROR_BAD_REQUEST.field = '[ESPECIALIDADE] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida a data da consulta
    if(consulta.data == undefined || consulta.data == null || String(consulta.data).trim() == ''){
        message.ERROR_BAD_REQUEST.field = '[DATA] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o horário da consulta
    if(consulta.hora == undefined || consulta.hora == null || String(consulta.hora).trim() == ''){
        message.ERROR_BAD_REQUEST.field = '[HORA] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o vínculo relacionado
    if(consulta.id_vinculo == undefined || consulta.id_vinculo == null || !Number.isInteger(Number(consulta.id_vinculo)) || Number(consulta.id_vinculo) <= 0){
        message.ERROR_BAD_REQUEST.field = '[ID_VINCULO] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    return false
}

const validarId = async (id) => {
    let message = JSON.parse(JSON.stringify(config_message))
    
    if(id == undefined || id == '' || id == null || id <= 0 || isNaN(id)){
        message.ERROR_BAD_REQUEST.field = '[ID] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    return false
}

const montarMensagem = async (base,status,response = null) => {
    base.DEFAULT_MESSAGE.status = status.status
    base.DEFAULT_MESSAGE.status_code = status.status_code
    base.DEFAULT_MESSAGE.message = status.message

    if(response != null) base.DEFAULT_MESSAGE.response.consulta = response

    return base.DEFAULT_MESSAGE // 200 ou 201
}

module.exports = {
    inserirNovaConsulta,
    atualizarConsulta,
    listarConsulta,
    buscarConsulta,
    excluirConsulta,
    listarConsultasByToken
}