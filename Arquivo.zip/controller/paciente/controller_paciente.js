/*************************************************************************************
 * Objetivo: Arquivo responsável pelo CRUD da tabela paciente
 * Data: 20/09/2026
 * Autor: Julio Augusto
 * Versão: 1.0
 * *********************************************************************************/

const config_message = require('../module/configMessages.js')
const pacienteDAO = require('../../model/DAO/paciente/paciente.js')
const usuarioController = require('../usuario/controller_usuario.js')
const vinculoController = require('../vinculo/controller_vinculo.js')
const profissionalDAO = require('../../model/DAO/profissional/profissional.js')
const bycrypt = require('../../services/bcrypt.js')
const { decodeJWT } = require('../../middleware/middlewareJWT.js')
const {uploadFiles} = require('../upload/controller_upload_azure.js')

// inserir nova paciente
const inserirNovaPaciente = async (paciente,foto_avatar, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))
    try {
        let validar = await validarDados(paciente, contentType)
        if(validar) return validar // 400 ou 415

        // e-mail e celular já cadastrados -> 409 (antes de criar o usuário)
        const duplicado = await profissionalDAO.selectCampoDuplicado({ email: paciente.email, celular: paciente.celular })
        if(duplicado){
            message.ERROR_CONFLICT.message = duplicado == 'email' ? 'E-mail já cadastrado.' : 'Celular já cadastrado.'
            message.ERROR_CONFLICT.field = `[${duplicado.toUpperCase()}] JÁ CADASTRADO`
            return message.ERROR_CONFLICT // 409
        }

        paciente.senha_hash = await bycrypt.criarHash(paciente.senha)
        paciente.nivel = 2 // define o nivel do usuario como paciente

        // Realiza o upload da imagem do paciente
        if (foto_avatar) {
            let urlImagem = await uploadFiles(foto_avatar)

            if (!urlImagem) {
                return message.ERROR_INTERNAL_SERVER_CONTROLLER
            }

            paciente.foto_avatar = urlImagem
        }

        let resultUsuario = await usuarioController.inserirNovaUsuario(paciente, contentType)
        if(!resultUsuario.status) return resultUsuario

        paciente.id_usuario = resultUsuario.response.usuario.id

        let result = await pacienteDAO.insertPaciente(paciente)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL

        let resultbuscarUsuario = await usuarioController.buscarUsuario(paciente.id_usuario)

        delete resultbuscarUsuario.response.usuario[0].senha
        delete resultbuscarUsuario.response.usuario[0].senha_hash
        delete paciente.senha
        delete paciente.senha_hash
        delete paciente.id_usuario

        paciente.id = result
        paciente.usuario = resultbuscarUsuario.response.usuario

        return await montarMensagem(message, message.SUCESS_CREATED_ITEM, paciente)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER
}

// atualizar paciente
const atualizarPaciente = async (paciente, id, foto_avatar, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        let validar = await validarDados(paciente, contentType)
        if(validar) return validar // 400 ou 415

        let resultBuscarId = await buscarPaciente(id)
        if(!resultBuscarId.status) return resultBuscarId // 400 e 404

        // Realiza o upload da imagem do paciente
        if (foto_avatar) {
            let urlImagem = await uploadFiles(foto_avatar)

            if (!urlImagem) {
                return message.ERROR_INTERNAL_SERVER_CONTROLLER
            }

            paciente.foto_avatar = urlImagem
        }

        paciente.id = Number(id)
        let result = await pacienteDAO.updatePaciente(paciente)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        return await montarMensagem(message, message.SUCESS_UPDATE_ITEM, paciente)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// listar todas pacientes
const listarPaciente = async () => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        let result = await pacienteDAO.selectAllPaciente()

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        // verfica se o array é vazio
        if(result.length <= 0) return message.ERROR_NOT_FOUND // status_code 404

        for (let paciente of result) {
            let usuario = await usuarioController.buscarUsuario(paciente.id_usuario)

            delete usuario.response.usuario[0].senha
            delete usuario.response.usuario[0].senha_hash

            if (usuario.status) {
                delete usuario.response.usuario[0].id
                Object.assign(paciente, usuario.response.usuario[0])
            }
        }

        let listarPacienteMessage = await montarMensagem(message, message.SUCESS_RESPONSE, result)
        message.DEFAULT_MESSAGE.response.count = result.length

        return listarPacienteMessage // status_code 200

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// buscar paciente pelo id
const buscarPaciente = async (id) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

       const validarID = await validarId(id)
       if(validarID) return validarID

        let result = await pacienteDAO.selectByIdPaciente(id)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        if(result.length < 1) return config_message.ERROR_NOT_FOUND

        for (let paciente of result) {
            let usuario = await usuarioController.buscarUsuario(paciente.id_usuario)

            delete usuario.response.usuario[0].senha
            delete usuario.response.usuario[0].senha_hash

            if (usuario.status) {
                delete usuario.response.usuario[0].id
                Object.assign(paciente, usuario.response.usuario[0])
            }
        }

        return await montarMensagem(message, message.SUCESS_RESPONSE, result)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// excluir paciente pelo id
const excluirPaciente = async (id) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let resultBuscarId = await buscarPaciente(id)
        if(!resultBuscarId.status) return resultBuscarId // 400 e 404

        let result = await pacienteDAO.deletePaciente(id)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        return await montarMensagem(message, message.SUCESS_DELETE_ITEM)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// buscar paciente pelo token (o token guarda o id do usuario, não o id do paciente)
const buscarPacienteByToken = async (token) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let decodedToken = await decodeJWT(token)
        if(!decodedToken.status) return message.ERROR_INVALID_TOKEN // 401

        let resultPaciente = await pacienteDAO.selectByIdUsuarioPaciente(decodedToken.decode.id)
        if(!resultPaciente) return message.ERROR_INTERNAL_SERVER_MODEL // 500
        if(resultPaciente.length < 1) return message.ERROR_NOT_FOUND // 404

        let idPaciente = resultPaciente[0].id
        let resultBuscarId = await buscarPaciente(idPaciente)

        return resultBuscarId // 200 ou 400 ou 404

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// editar paciente pelo token
const editarPacienteByToken = async (paciente, token, foto_avatar, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        let decodedToken = await decodeJWT(token)
        if(!decodedToken.status) return message.ERROR_INVALID_TOKEN // 401

        let resultPaciente = await pacienteDAO.selectByIdUsuarioPaciente(decodedToken.decode.id)
        if(!resultPaciente) return message.ERROR_INTERNAL_SERVER_MODEL // 500
        if(resultPaciente.length < 1) return message.ERROR_NOT_FOUND // 404

        paciente.id = Number(resultPaciente[0].id)

        // Realiza o upload da imagem do paciente
        if (foto_avatar) {
            let urlImagem = await uploadFiles(foto_avatar)

            if (!urlImagem) {
                return message.ERROR_INTERNAL_SERVER_CONTROLLER
            }

            paciente.foto_avatar = urlImagem
        }

        let result = await pacienteDAO.updatePaciente(paciente)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        return await montarMensagem(message, message.SUCESS_UPDATE_ITEM, paciente)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// primeiro acesso do paciente
const primeiroAcessoPaciente = async (paciente, token) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        let decodedToken = await decodeJWT(token)
        if(!decodedToken.status) return message.ERROR_INVALID_TOKEN // 401

        let validar = await validarDadosPrimeiroAcesso(paciente)
        if(validar) return validar // 400

        let resultPaciente = await pacienteDAO.selectByIdUsuarioPaciente(decodedToken.decode.id)
        if(!resultPaciente) return message.ERROR_INTERNAL_SERVER_MODEL // 500
        if(resultPaciente.length < 1) return message.ERROR_NOT_FOUND // 404

        let idPaciente = resultPaciente[0].id

        let result = await pacienteDAO.updatePrimeiroAcessoPaciente(paciente, idPaciente)

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        return await montarMensagem(message, message.SUCESS_UPDATE_ITEM, paciente)

    } catch (error) {
        console.log(error)
    }
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// listar profissionais vinculados ao paciente
const listarProfissionaisVinculados = async (token, filtro) => {
    const profissionalController = require('../profissional/controller_profissional.js')
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let decodedToken = await decodeJWT(token)
        if(!decodedToken.status) return message.ERROR_INVALID_TOKEN // 401

        let resultPaciente = await pacienteDAO.selectByIdUsuarioPaciente(decodedToken.decode.id)
        if(!resultPaciente) return message.ERROR_INTERNAL_SERVER_MODEL // 500
        if(resultPaciente.length < 1) return message.ERROR_NOT_FOUND // 404

        let idPaciente = resultPaciente[0].id

        let resultBuscarId = await buscarPaciente(idPaciente)
        if(!resultBuscarId.status) return resultBuscarId // 400 e 404

        let result = await vinculoController.listarProfissionaisByIdPaciente(idPaciente, filtro)

        if (!result) return message.ERROR_INTERNAL_SERVER_MODEL

        if (!result.status) return result

        let profissionais = result.response.vinculo

        if (!Array.isArray(profissionais) || profissionais.length <= 0) {
            return message.ERROR_NOT_FOUND
        }

        for (let profissional of profissionais) {
            let resultBuscarProfissional = await profissionalController.buscarProfissional(profissional.id)

            if (resultBuscarProfissional.status && resultBuscarProfissional.response?.usuario?.length > 0) {
                profissional = resultBuscarProfissional.response.profissional
            }
        }

        let listarProfissionaisMessage = await montarMensagem(
            message,
            message.SUCESS_RESPONSE,
            profissionais
        )

        message.DEFAULT_MESSAGE.response.count = profissionais.length

        listarProfissionaisMessage.response.profissional = listarProfissionaisMessage.response.paciente
        delete listarProfissionaisMessage.response.paciente

        return listarProfissionaisMessage

    } catch (error) {
        console.log(error)
    }

    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// insere um novo vinculo entre profissional e paciente
const inserirNovoVinculo = async (token, idProfissional) => {
    const profissionalController = require('../profissional/controller_profissional.js')
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let decodedToken = await decodeJWT(token)
        if(!decodedToken.status) return message.ERROR_INVALID_TOKEN // 401

        let resultPaciente = await pacienteDAO.selectByIdUsuarioPaciente(decodedToken.decode.id)
        if(!resultPaciente) return message.ERROR_INTERNAL_SERVER_MODEL // 500
        if(resultPaciente.length < 1) return message.ERROR_NOT_FOUND // 404

        let idPaciente = resultPaciente[0].id

        let resultBuscarIdPaciente = await buscarPaciente(idPaciente)
        if(!resultBuscarIdPaciente.status) return resultBuscarIdPaciente // 400 e 404

        let resultBuscarIdProfissional = await profissionalController.buscarProfissional(idProfissional)
        if(!resultBuscarIdProfissional.status) return resultBuscarIdProfissional // 400 e 404

        let vinculo = {
            id_paciente: idPaciente,
            id_profissional: idProfissional
        }

        let result = await vinculoController.inserirNovoVinculoByPaciente(vinculo)

        if(!result.status) return result // 400, 404 e 500

        return await montarMensagem(message, message.SUCESS_CREATED_ITEM, vinculo)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// exclui um vinculo entre profissional e paciente
const excluirVinculo = async (token, idProfissional) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {

        let decodedToken = await decodeJWT(token)
        if(!decodedToken.status) return message.ERROR_INVALID_TOKEN // 401

        let resultPaciente = await pacienteDAO.selectByIdUsuarioPaciente(decodedToken.decode.id)
        if(!resultPaciente) return message.ERROR_INTERNAL_SERVER_MODEL // 500
        if(resultPaciente.length < 1) return message.ERROR_NOT_FOUND // 404

        let idPaciente = resultPaciente[0].id

        let result = await vinculoController.excluirVinculoPacienteProfissional(idPaciente, idProfissional)

        if(!result.status) return result // 400, 404 e 500

        return await montarMensagem(message, message.SUCESS_DELETE_ITEM)

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

// buscar paciente pelo nome ou e-mail
const buscarPacientePorNomeOuEmail = async (busca) => {
    let message = JSON.parse(JSON.stringify(config_message))

    try {
        const validarBusca = await validarTermoBusca(busca)
        if(validarBusca) return validarBusca // 400

        let result = await pacienteDAO.selectBuscaPaciente(busca.trim())

        if(!result) return message.ERROR_INTERNAL_SERVER_MODEL // 500

        // verifica se o array é vazio
        if(result.length <= 0) return message.ERROR_NOT_FOUND // 404

        let buscaPacienteMessage = await montarMensagem(message, message.SUCESS_RESPONSE, result)
        message.DEFAULT_MESSAGE.response.count = result.length

        return buscaPacienteMessage // 200

    } catch (error) {console.log(error)}
    return message.ERROR_INTERNAL_SERVER_CONTROLLER // 500
}

const validarDados = async (paciente, contentType) => {
    let message = JSON.parse(JSON.stringify(config_message))

    // Valida se o formato de dados é JSON
    // Valida o formato da requisição
    if(String(contentType).toLowerCase() != 'application/json' && !String(contentType).toLowerCase().includes('multipart/form-data')) return message.ERROR_CONTENT_TYPE // Status code 415

    // Garante que o objeto foi informado
    if(paciente == undefined || paciente == null || typeof paciente != 'object'){
        message.ERROR_BAD_REQUEST.field = '[PACIENTE] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o nome completo
    if(typeof paciente.nome_completo != 'string' || paciente.nome_completo.trim() == '' || paciente.nome_completo.length > 150){
        message.ERROR_BAD_REQUEST.field = '[NOME_COMPLETO] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o apelido opcional
    if(paciente.apelido != undefined && paciente.apelido != null &&
       (typeof paciente.apelido != 'string' || paciente.apelido.length > 80)){
        message.ERROR_BAD_REQUEST.field = '[APELIDO] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o celular opcional
    if(paciente.celular != undefined && paciente.celular != null &&
       (typeof paciente.celular != 'string' || paciente.celular.length > 20)){
        message.ERROR_BAD_REQUEST.field = '[CELULAR] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o e-mail
    if(paciente.email == undefined || paciente.email == null ||
       paciente.email.length > 150){
        message.ERROR_BAD_REQUEST.field = '[EMAIL] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida a senha 
    if(paciente.senha == undefined || paciente.senha == null ||
       (typeof paciente.senha != 'string' || paciente.senha.length > 30)){
        message.ERROR_BAD_REQUEST.field = '[SENHA] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida o avatar opcional
    if(paciente.foto_avatar != undefined && paciente.foto_avatar != null &&
       (typeof paciente.foto_avatar != 'string' || paciente.foto_avatar.length > 255)){
        message.ERROR_BAD_REQUEST.field = '[FOTO_AVATAR] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida a data de nascimento opcional
    if(paciente.data_nascimento != undefined && paciente.data_nascimento != null && String(paciente.data_nascimento).trim() == ''){
        message.ERROR_BAD_REQUEST.field = '[DATA_NASCIMENTO] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    return false
}

const validarDadosPrimeiroAcesso = async (paciente) => {
    let message = JSON.parse(JSON.stringify(config_message))

    // Valida o apelido opcional
    if(paciente.apelido != undefined && paciente.apelido != null &&
       (typeof paciente.apelido != 'string' || paciente.apelido.length > 80)){
        message.ERROR_BAD_REQUEST.field = '[APELIDO] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    // Valida a data de nascimento opcional
    if(paciente.data_nascimento != undefined && paciente.data_nascimento != null && !validarDataNascimento(paciente.data_nascimento)){
        message.ERROR_BAD_REQUEST.field = '[DATA_NASCIMENTO] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    return false
}

const validarTermoBusca = async (busca) => {
    let message = JSON.parse(JSON.stringify(config_message))

    if(typeof busca != 'string' || busca.trim() == '' || busca.length > 150){
        message.ERROR_BAD_REQUEST.field = '[BUSCA] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    return false
}

// verifica se a data está no formato AAAA-MM-DD, existe no calendário e não é futura
const validarDataNascimento = (data) => {
    if(typeof data != 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(data)) return false

    const [ano, mes, dia] = data.split('-').map(Number)
    const dataInformada = new Date(Date.UTC(ano, mes - 1, dia))

    // datas como 2026-02-30 são ajustadas pelo Date e deixam de bater com o valor informado
    if(dataInformada.getUTCFullYear() != ano || dataInformada.getUTCMonth() != mes - 1 || dataInformada.getUTCDate() != dia) return false

    const agora = new Date()
    const hoje = Date.UTC(agora.getFullYear(), agora.getMonth(), agora.getDate())

    return dataInformada.getTime() <= hoje
}

const validarId = async (id) => {
    let message = JSON.parse(JSON.stringify(config_message))
    
    if(id == undefined || id == '' || id == null || id <= 0 || isNaN(id)){
        message.ERROR_BAD_REQUEST.field = '[ID] INVÁLIDO'
        return message.ERROR_BAD_REQUEST // 400
    }

    return false
}

const montarMensagem = async (base,status,response = null) => {
    base.DEFAULT_MESSAGE.status = status.status
    base.DEFAULT_MESSAGE.status_code = status.status_code
    base.DEFAULT_MESSAGE.message = status.message

    if(response != null) base.DEFAULT_MESSAGE.response.paciente = response

    return base.DEFAULT_MESSAGE // 200 ou 201
}

module.exports = {
    inserirNovaPaciente,
    atualizarPaciente,
    listarPaciente,
    buscarPaciente,
    excluirPaciente,
    buscarPacienteByToken,
    editarPacienteByToken,
    primeiroAcessoPaciente,
    listarProfissionaisVinculados,
    inserirNovoVinculo,
    excluirVinculo,
    buscarPacientePorNomeOuEmail
}